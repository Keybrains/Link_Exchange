// ----------------------------------------------------------------------

const account = {
  displayName: 'Vaibhav Makwana',
  email: 'vaibhavmakwana@gmail.com',
  photoURL: '/static/mock-images/avatars/avatar_6.jpg',
};

export default account;
