// ----------------------------------------------------------------------

const account = {
  displayName: 'Vaibhav Makwana',
  email: 'vaibhavmakwana@gmail.com',
  photoURL: '/static/mock-images/avatars/avatar_25.jpg',
};

export default account;
