export { default as RegisterForm } from './AdminRegisterForm';
